// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause
namespace src_gui_text_qtextdocument {

/* wrap non-code snippet

//! [0]
<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>...
//! [0]

*/ // wrap non-code snippet
} // src_gui_text_qtextdocument
